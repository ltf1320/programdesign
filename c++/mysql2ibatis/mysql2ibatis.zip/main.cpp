#include <iostream>
#include <cstdio>
#include <cstring>
#include <string>
#include <algorithm>
#include <cstdlib>
using namespace std;
const int maxn=100;
const int maxm=1000;
struct sqlField
{
    int id;
    string name;
    string Schema;
    string table;
    string Type;
    int displaySize;
    int Percision;
    int Scale;
};
sqlField fds[maxn];
int cnt=0;

void getNext(char* tmp)
{
    char tch;
    int tn=0;
    while(1)
    {
        tch=getchar();
        if(tch==','||tch=='\n')
            break;
        tmp[tn++]=tch;
    }
    tmp[tn]=0;
}

char toUpperCase(char ch)
{
    if(ch>='a'&&ch<='z')
        ch-=32;
    return ch;
}
//�»��߸��շ�
string changeNameStyle(string str)
{
    char tmp[maxm];
    int len=0;
    for(size_t i=0;i<str.length();i++)
    {
        if(str[i]=='_')
        {
            tmp[len++]=toUpperCase(str[i+1]);
            i++;
            continue;
        }
        tmp[len++]=str[i];
    }
    tmp[len]=0;
    return string(tmp);
}

void read()
{
    sqlField tf;
    char tmp[maxm];
    while(cin>>tf.id)
    {
        getchar();
        getNext(tmp);
        tf.name=string(tmp);
        getNext(tmp);
        tf.Schema= string(tmp);
        getNext(tmp);
        tf.table= string(tmp);
        getNext(tmp);
        tf.Type= string(tmp);
        getNext(tmp);
        sscanf(tmp,"%d",&tf.displaySize);
        getNext(tmp);
        sscanf(tmp,"%d",&tf.Percision);
        getNext(tmp);
        sscanf(tmp,"%d",&tf.Scale);
        fds[cnt++]=tf;
    }
}
//����ibatis�����ļ���
void printIbatisResultMap()
{
    for(int i=0;i<cnt;i++)
    {
        cout<<"<result column=\""<<fds[i].name<<"\" property=\""<<changeNameStyle(fds[i].name)<<"\" jdbcType=\""<<fds[i].Type<<"\"/>"<<endl;
    }
}

void printSelectSQL()
{
    cout<<"select ";
    for(int i=0;i<cnt;i++)
    {
        cout<<fds[i].name;
        if(i!=cnt-1)
            cout<<',';
    }
    cout<<" from "<<fds[0].table<<" where";
}

int main()
{
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
    read();
   printIbatisResultMap();
   cout<<endl;
    printSelectSQL();

    return 0;
}
